from __future__ import annotations

# from .eng.Core17InstructionRetrieval import *
# from .eng.News21InstructionRetrieval import *
# from .eng.Robust04InstructionRetrieval import *
from .eng.ClarityInstructionRetrieval import *
from .eng.SourceInstructionRetrieval import *
from .eng.AudienceInstructionRetrieval import *
from .eng.LanguageInstructionRetrieval import *
from .eng.FormatInstructionRetrieval import *
from .eng.LengthInstructionRetrieval import *
# from .eng.Test1InstructionRetrieval import *
# from .eng.Test2InstructionRetrieval import *