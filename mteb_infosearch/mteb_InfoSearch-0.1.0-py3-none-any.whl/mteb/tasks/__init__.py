from __future__ import annotations

from .BitextMining import *
from .Classification import *
from .Clustering import *
from .InstructionRetrieval import *
from .PairClassification import *
from .Reranking import *
from .Retrieval import *
from .STS import *
from .Summarization import *
