from __future__ import annotations

from .dan.BornholmskBitextMining import *
from .kat.TbilisiCityHallBitextMining import *
from .multilingual.BibleNLPBitextMining import *
from .multilingual.BUCCBitextMining import *
from .multilingual.DiaBLaBitextMining import *
from .multilingual.FloresBitextMining import *
from .multilingual.IN22ConvBitextMining import *
from .multilingual.IN22GenBitextMining import *
from .multilingual.norwegian_courts_bitext_mining import *
from .multilingual.NorwegianCourtsBitextMining import *
from .multilingual.NTREXBitextMining import *
from .multilingual.RomaTalesBitextMining import *
from .multilingual.TatoebaBitextMining import *
from .srn.SRNCorpusBitextMining import *
from .vie.VieMedEVBitextMining import *
